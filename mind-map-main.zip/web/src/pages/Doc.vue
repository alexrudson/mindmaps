T<template>
  <div class="doc">
    文档已迁移至：<a href="https://wanglin2.github.io/mind-map-docs/">新地址</a>
  </div>
</template>

<style lang="less" scoped>
.doc {
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: 20px;

  a {
    color: #1ea59a;
  }
}
</style>
