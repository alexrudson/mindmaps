export default {
  // Geral
  'app.name': 'Mapa Mental',
  'app.welcome': 'Bem-vindo ao Mapa Mental',
  'app.loading': 'Carregando...',
  
  // Menu
  'menu.file': 'Arquivo',
  'menu.edit': 'Editar',
  'menu.view': 'Visualizar',
  'menu.help': 'Ajuda',
  
  // Arquivo
  'file.new': 'Novo',
  'file.open': 'Abrir',
  'file.save': 'Salvar',
  'file.saveAs': 'Salvar Como',
  'file.import': 'Importar',
  'file.export': 'Exportar',
  'file.exit': 'Sair',
  
  // Editar
  'edit.undo': 'Desfazer',
  'edit.redo': 'Refazer',
  'edit.cut': 'Recortar',
  'edit.copy': 'Copiar',
  'edit.paste': 'Colar',
  'edit.delete': 'Excluir',
  
  // Visualizar
  'view.zoomIn': 'Aumentar Zoom',
  'view.zoomOut': 'Diminuir Zoom',
  'view.fit': 'Ajustar à Tela',
  'view.fullscreen': 'Tela Cheia',
  
  // Ajuda
  'help.about': 'Sobre',
  'help.shortcuts': 'Atalhos',
  'help.feedback': 'Feedback',
  
  // Mensagens
  'msg.saveSuccess': 'Salvo com sucesso',
  'msg.saveFailed': 'Falha ao salvar',
  'msg.loadSuccess': 'Carregado com sucesso',
  'msg.loadFailed': 'Falha ao carregar',
  'msg.deleteConfirm': 'Tem certeza que deseja excluir?',
  
  // Estruturas
  'structure.mindmap': 'Mapa Mental',
  'structure.organization': 'Organograma',
  'structure.timeline': 'Linha do Tempo',
  'structure.fishbone': 'Diagrama de Ishikawa',
  
  // Temas
  'theme.default': 'Padrão',
  'theme.dark': 'Escuro',
  'theme.light': 'Claro',
  'theme.custom': 'Personalizado',
  
  // Exportação
  'export.png': 'Exportar como PNG',
  'export.svg': 'Exportar como SVG',
  'export.pdf': 'Exportar como PDF',
  'export.json': 'Exportar como JSON',
  'export.markdown': 'Exportar como Markdown',
  
  // Importação
  'import.json': 'Importar JSON',
  'import.markdown': 'Importar Markdown',
  'import.xmind': 'Importar XMind',
  
  // Configurações
  'settings.general': 'Geral',
  'settings.appearance': 'Aparência',
  'settings.shortcuts': 'Atalhos',
  'settings.language': 'Idioma',
  
  // Atalhos
  'shortcut.new': 'Novo (Ctrl+N)',
  'shortcut.open': 'Abrir (Ctrl+O)',
  'shortcut.save': 'Salvar (Ctrl+S)',
  'shortcut.undo': 'Desfazer (Ctrl+Z)',
  'shortcut.redo': 'Refazer (Ctrl+Y)',
  'shortcut.copy': 'Copiar (Ctrl+C)',
  'shortcut.paste': 'Colar (Ctrl+V)',
  'shortcut.delete': 'Excluir (Delete)',
  'shortcut.zoomIn': 'Aumentar Zoom (Ctrl++)',
  'shortcut.zoomOut': 'Diminuir Zoom (Ctrl+-)',
  'shortcut.fit': 'Ajustar à Tela (Ctrl+0)',
  
  // Erros
  'error.unknown': 'Erro desconhecido',
  'error.network': 'Erro de rede',
  'error.fileNotFound': 'Arquivo não encontrado',
  'error.invalidFile': 'Arquivo inválido',
  'error.unsupportedFormat': 'Formato não suportado'
} 