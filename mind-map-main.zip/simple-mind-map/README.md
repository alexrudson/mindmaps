# 一个web思维导图的简单实现

详细文档见：[https://github.com/wanglin2/mind-map](https://github.com/wanglin2/mind-map)