import defaultTheme from './default'

export default {
  default: defaultTheme
}
